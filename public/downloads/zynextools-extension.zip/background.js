/** Temporary DNR rule ids for panel Referer unlock (session rules). */
const UNLOCK_RULE_TTL_MS = 45000;
/** Settle after clearing + writing cookies so ChatGPT/session jar is ready before navigate. */
const SETTLE_MS = 700;
/** Pak SEO opens panels from the app dashboard host — prefer this Referer. */
const DEFAULT_PANEL_REFERRER = 'https://app.pakseotools.com/';
const APEX_PANEL_REFERRER = 'https://pakseotools.com/';
const APP_PANEL_REFERRER = DEFAULT_PANEL_REFERRER;
const MEMBER_PANEL_REFERRER = 'https://app.pakseotools.com/member';
let nextRuleId = 900001;
const activeUnlockByTab = new Map(); // tabId -> { ruleIds, timer }

function destinationHost(destinationUrl) {
  try {
    return new URL(destinationUrl).hostname.toLowerCase();
  } catch {
    return '';
  }
}

function normalizeDomain(domain) {
  return String(domain || '').trim().toLowerCase().replace(/^\./, '');
}

function isToolAccessHost(hostname) {
  const host = String(hostname || '').toLowerCase();
  return host === 'toolaccess.click' || host.endsWith('.toolaccess.click');
}

function cookieUrlFor(host, path, secure) {
  const cleanHost = String(host || '').replace(/^\./, '');
  const cleanPath = path && String(path).startsWith('/') ? String(path) : `/${path || ''}`;
  return `${secure ? 'https' : 'http'}://${cleanHost}${cleanPath || '/'}`;
}

function sameSite(value) {
  const raw = String(value || '').toLowerCase();
  if (raw === 'lax') return 'lax';
  if (raw === 'strict') return 'strict';
  if (raw === 'no_restriction' || raw === 'none') return 'no_restriction';
  return undefined;
}

function expirationDate(cookie) {
  if (cookie.expirationDate != null && cookie.expirationDate !== '') {
    const n = Number(cookie.expirationDate);
    return Number.isFinite(n) ? n : undefined;
  }
  if (cookie.expires != null && cookie.expires !== '' && cookie.expires !== -1) {
    const n = Number(cookie.expires);
    if (!Number.isFinite(n)) return undefined;
    return n > 1e12 ? n / 1000 : n;
  }
  return undefined;
}

function buildSetDetails(cookie, url, domain) {
  const secureDest = /^https:/i.test(url);
  let secure = cookie.secure;
  if (secure == null) secure = secureDest;
  else secure = Boolean(secure);

  const name = String(cookie.name || '');
  const site = sameSite(cookie.sameSite);
  if (site === 'no_restriction') secure = true;

  // Chrome rejects domain on __Host- cookies; __Secure- must be Secure.
  if (name.startsWith('__Host-')) {
    secure = true;
  } else if (name.startsWith('__Secure-')) {
    secure = true;
  }

  const details = {
    url,
    name,
    value: String(cookie.value ?? ''),
    path: name.startsWith('__Host-') ? '/' : cookie.path || '/',
    secure: Boolean(secure),
    httpOnly: Boolean(cookie.httpOnly),
  };

  const hostOnly = cookie.hostOnly === true || name.startsWith('__Host-');
  if (domain && !hostOnly) details.domain = domain;

  const exp = expirationDate(cookie);
  if (exp != null) details.expirationDate = exp;
  if (site) details.sameSite = site;
  return details;
}

async function setOne(details) {
  try {
    await chrome.cookies.set(details);
    return true;
  } catch (error) {
    // Retry host-only (no domain) — common for ChatGPT session cookies.
    if (details.domain) {
      try {
        const retry = { ...details };
        delete retry.domain;
        await chrome.cookies.set(retry);
        return true;
      } catch (error2) {
        console.warn('Could not set cookie', details.name, details.url, error2);
        return false;
      }
    }
    console.warn('Could not set cookie', details.name, details.url, details.domain, error);
    return false;
  }
}

async function removeOne(cookie) {
  try {
    const host = normalizeDomain(cookie.domain) || destinationHost(cookie.url || '');
    if (!host && !cookie.url) return false;
    const url =
      cookie.url ||
      cookieUrlFor(host, cookie.path || '/', cookie.secure !== false);
    await chrome.cookies.remove({ url, name: String(cookie.name) });
    return true;
  } catch (error) {
    console.warn('Could not remove cookie', cookie?.name, error);
    return false;
  }
}

/**
 * Wipe existing cookies for destination + export domains BEFORE applying admin
 * cookies. Otherwise a customer's personal ChatGPT/session cookies can win.
 */
async function clearSiteCookies(destinationUrl, cookieList) {
  const hosts = new Set();
  const urls = new Set();
  const pushHost = (raw) => {
    const host = normalizeDomain(raw);
    if (!host) return;
    hosts.add(host);
    const parts = host.split('.');
    if (parts.length >= 2) hosts.add(parts.slice(-2).join('.'));
  };
  const pushUrl = (raw) => {
    try {
      const u = new URL(String(raw));
      urls.add(`${u.protocol}//${u.hostname}/`);
    } catch {
      /* ignore */
    }
  };

  pushHost(destinationHost(destinationUrl));
  pushUrl(destinationUrl);
  for (const cookie of Array.isArray(cookieList) ? cookieList : []) {
    if (!cookie) continue;
    if (cookie.domain) pushHost(cookie.domain);
    if (cookie.url) {
      pushHost(destinationHost(String(cookie.url)));
      pushUrl(cookie.url);
    }
  }

  // ChatGPT / OpenAI aliases — personal sessions often live across these hosts.
  if ([...hosts].some((h) => /chatgpt\.com|openai\.com|oaistatic\.com/i.test(h))) {
    pushHost('chatgpt.com');
    pushHost('chat.openai.com');
    pushHost('auth0.openai.com');
    pushHost('auth.openai.com');
    pushHost('oaistatic.com');
    urls.add('https://chatgpt.com/');
    urls.add('https://chat.openai.com/');
    urls.add('https://auth0.openai.com/');
    urls.add('https://auth.openai.com/');
  }

  let removed = 0;
  for (const url of urls) {
    try {
      const existing = await chrome.cookies.getAll({ url });
      for (const cookie of existing || []) {
        if (await removeOne(cookie)) removed += 1;
      }
    } catch (error) {
      console.warn('Could not list cookies for url', url, error);
    }
  }
  for (const host of hosts) {
    try {
      const existing = await chrome.cookies.getAll({ domain: host });
      for (const cookie of existing || []) {
        if (await removeOne(cookie)) removed += 1;
      }
    } catch (error) {
      console.warn('Could not list cookies for', host, error);
    }
  }
  return removed;
}

/**
 * Clear cookies + localStorage + indexedDB for the tool origin so a customer's
 * personal ChatGPT session cannot revive after we set admin cookies.
 */
async function clearSiteStorage(destinationUrl) {
  if (!chrome.browsingData?.remove) return false;
  let origin = '';
  try {
    origin = new URL(destinationUrl).origin;
  } catch {
    return false;
  }
  const origins = [origin];
  if (/chatgpt\.com|openai\.com/i.test(origin)) {
    origins.push(
      'https://chatgpt.com',
      'https://www.chatgpt.com',
      'https://chat.openai.com',
      'https://auth0.openai.com',
      'https://auth.openai.com',
    );
  }
  try {
    await chrome.browsingData.remove(
      { origins: [...new Set(origins)] },
      { cookies: true, localStorage: true, indexedDB: true },
    );
    return true;
  } catch (error) {
    console.warn('browsingData.remove failed', error);
    return false;
  }
}

/**
 * For *.toolaccess.click destinations: write matching cookies as
 * host-only on the exact subdomain AND on parent .toolaccess.click.
 * Never remaps foreign domains (e.g. chatgpt.com) onto the panel.
 */
async function applyOnToolAccessPanel(cookie, destHost, path, destIsHttps) {
  let setCount = 0;
  const destUrl = cookieUrlFor(destHost, path, destIsHttps);
  if (await setOne(buildSetDetails(cookie, destUrl, undefined))) setCount += 1;

  const parent = '.toolaccess.click';
  const parentUrl = cookieUrlFor('toolaccess.click', path, destIsHttps);
  if (await setOne(buildSetDetails(cookie, parentUrl, parent))) setCount += 1;

  if (destHost !== 'toolaccess.click') {
    const apexUrl = cookieUrlFor('toolaccess.click', path, destIsHttps);
    if (await setOne(buildSetDetails(cookie, apexUrl, undefined))) setCount += 1;
  }
  return setCount;
}

async function removeUnlockRules(ruleIds) {
  const ids = (ruleIds || []).filter((id) => Number.isFinite(id));
  if (!ids.length || !chrome.declarativeNetRequest?.updateSessionRules) return;
  try {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: ids, addRules: [] });
  } catch (error) {
    console.warn('Could not remove unlock DNR rules', error);
  }
}

function clearTabUnlock(tabId) {
  const entry = activeUnlockByTab.get(tabId);
  if (!entry) return;
  if (entry.timer) clearTimeout(entry.timer);
  activeUnlockByTab.delete(tabId);
  void removeUnlockRules(entry.ruleIds);
}

function normalizeUnlockReferrer(raw) {
  const trimmed = String(raw || '').trim();
  if (!trimmed) return '';
  try {
    const u = new URL(trimmed);
    if (!/^https?:$/i.test(u.protocol)) return trimmed;
    if (/\/(login|signin|sign-in|sign_in|register|signup|sign-up)\/?$/i.test(u.pathname)) {
      return `${u.origin}/`;
    }
    if (!u.pathname || u.pathname === '/') return `${u.origin}/`;
    return trimmed;
  } catch {
    return trimmed;
  }
}

function buildReferrerCandidates(primary, extraList) {
  const out = [];
  const push = (v) => {
    const s = String(v || '').trim();
    if (s && !out.includes(s)) out.push(s);
  };
  const list = Array.isArray(extraList) ? extraList : [];
  push(normalizeUnlockReferrer(primary));
  push(primary);
  for (const item of list) {
    push(normalizeUnlockReferrer(item));
    push(item);
  }
  push(DEFAULT_PANEL_REFERRER);
  push(APEX_PANEL_REFERRER);
  push(MEMBER_PANEL_REFERRER);
  push(APP_PANEL_REFERRER);
  return out;
}

function allocRuleId() {
  const id = nextRuleId++;
  if (nextRuleId > 990000) nextRuleId = 900001;
  return id;
}

/**
 * Install temporary session DNR rules to set Referer (and Origin when allowed)
 * on requests to the toolaccess host. Tries candidate Referers (highest priority first).
 * Returns rule ids or [] if unavailable.
 */
async function installUnlockReferrerRules(destinationUrl, referrerUrl, referrerCandidates) {
  const destHost = destinationHost(destinationUrl);
  if (!isToolAccessHost(destHost)) return { ruleIds: [], mode: 'none', referrer: '' };
  if (!chrome.declarativeNetRequest?.updateSessionRules) {
    return { ruleIds: [], mode: 'unsupported', referrer: '' };
  }

  const candidates = buildReferrerCandidates(referrerUrl, referrerCandidates);
  if (!candidates.length) {
    return { ruleIds: [], mode: 'invalid', referrer: '' };
  }

  const resourceTypes = [
    'main_frame',
    'sub_frame',
    'xmlhttprequest',
    'websocket',
    'other',
    'script',
    'stylesheet',
    'image',
    'font',
    'ping',
  ];

  // Cover exact subdomain + parent apex (redirects / shared assets).
  const hosts = [destHost];
  if (destHost !== 'toolaccess.click') hosts.push('toolaccess.click');

  const tryAddBundle = async (referrer, withOrigin) => {
    let origin = '';
    try {
      origin = new URL(referrer).origin;
    } catch {
      throw new Error('invalid referrer');
    }

    const ruleIds = [];
    const addRules = [];
    let priority = 100 + candidates.length;

    for (const host of hosts) {
      const ruleId = allocRuleId();
      ruleIds.push(ruleId);
      const requestHeaders = [{ header: 'Referer', operation: 'set', value: referrer }];
      if (withOrigin) {
        requestHeaders.push({ header: 'Origin', operation: 'set', value: origin });
      }
      addRules.push({
        id: ruleId,
        priority: priority--,
        action: { type: 'modifyHeaders', requestHeaders },
        condition: {
          requestDomains: [host],
          resourceTypes,
        },
      });
    }

    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: ruleIds,
      addRules,
    });
    return ruleIds;
  };

  // Prefer first candidate (normalized admin value). Only one Referer can win per request;
  // we install that winner for dest + apex hosts.
  let lastError = null;
  for (const referrer of candidates) {
    try {
      const ruleIds = await tryAddBundle(referrer, true);
      return { ruleIds, mode: 'referer+origin', referrer };
    } catch (err1) {
      lastError = err1;
      console.warn('DNR Origin rewrite rejected, trying Referer only', referrer, err1);
      try {
        const ruleIds = await tryAddBundle(referrer, false);
        return { ruleIds, mode: 'referer', referrer };
      } catch (err2) {
        lastError = err2;
        console.warn('DNR Referer rewrite failed for candidate', referrer, err2);
      }
    }
  }

  console.warn('DNR Referer rewrite unavailable for all candidates', lastError);
  return { ruleIds: [], mode: 'failed', referrer: candidates[0] || '' };
}

/**
 * Fallback when DNR cannot set Referer: open an extension page that navigates
 * with location.replace after a document.referrer context is limited — Chrome
 * still may not send a custom Referer from extension pages. Documented limit.
 */
async function openWithReferrerFallback(destinationUrl, referrerUrl) {
  const dest = encodeURIComponent(destinationUrl);
  const ref = encodeURIComponent(String(referrerUrl || ''));
  const url = chrome.runtime.getURL(`unlock.html?dest=${dest}&ref=${ref}`);
  return chrome.tabs.create({ url });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Apply Copy-Cookies JSON via chrome.cookies.set using each cookie's own
 * domain/url from the export (e.g. chatgpt.com cookies stay on chatgpt.com).
 *
 * For toolaccess.click destinations, also dual-write toolaccess-scoped
 * cookies onto the exact host (host-only) + parent domain before navigate.
 * When unlockReferrer is set (or panel dest), install temporary DNR Referer
 * rules and wait for cookie apply + settle before opening the tab.
 */
async function injectChatGptPrivacy(tabId, isolationKey, brandName) {
  const key = String(isolationKey || 'anon');
  const brand = String(brandName || 'ZynexTools');
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: (KEY_RAW, BRAND) => {
        if (window.__ZYNEX_PRIVACY__) return;
        window.__ZYNEX_PRIVACY__ = true;
        const KEY = 'zynex_hist_' + KEY_RAW;
        const mine = () => {
          try {
            return JSON.parse(localStorage.getItem(KEY) || '[]');
          } catch {
            return [];
          }
        };
        const save = ids => {
          try {
            localStorage.setItem(KEY, JSON.stringify(ids.slice(-300)));
          } catch {}
        };
        const remember = id => {
          if (!id) return;
          const a = mine();
          if (!a.includes(id)) {
            a.push(id);
            save(a);
          }
        };
        const currentId = () => {
          const m = String(location.pathname || '').match(/\/c\/([a-zA-Z0-9_-]+)/);
          return m ? m[1] : '';
        };
        try {
          document.title = BRAND;
        } catch {}
        const style = document.createElement('style');
        style.textContent =
          'a[href="/library"],a[href*="/library"],a[href="/projects"],a[href*="/projects"],a[href*="/gpts"],[data-zynex-hide="1"]{display:none!important}';
        (document.head || document.documentElement).appendChild(style);
        const filter = () => {
          const allowed = Object.create(null);
          mine().forEach(id => {
            allowed[id] = true;
          });
          const cur = currentId();
          if (cur) remember(cur);
          document.querySelectorAll('a[href*="/c/"]').forEach(a => {
            const m = (a.getAttribute('href') || '').match(/\/c\/([a-zA-Z0-9_-]+)/);
            if (!m) return;
            const id = m[1];
            const row = a.closest('li') || a.parentElement;
            if (!row) return;
            if (allowed[id] || id === cur) {
              row.removeAttribute('data-zynex-hide');
              row.style.display = '';
            } else {
              row.setAttribute('data-zynex-hide', '1');
              row.style.display = 'none';
            }
          });
        };
        setInterval(filter, 900);
        filter();
      },
      args: [key, brand],
    });
  } catch (e) {
    console.warn('[zynex] privacy inject failed', e);
  }
}

async function applyCookies(cookies, destinationUrl, openTab, unlockReferrer, referrerCandidates, privacy) {
  const list = Array.isArray(cookies) ? cookies : [];
  const destHost = destinationHost(destinationUrl);
  const destIsHttps = !/^http:\/\//i.test(destinationUrl || '');
  const destIsPanel = isToolAccessHost(destHost);
  const primary =
    normalizeUnlockReferrer(unlockReferrer) ||
    (destIsPanel ? DEFAULT_PANEL_REFERRER : '');
  const referrer = destIsPanel ? primary : '';
  let setCount = 0;
  let unlockMode = 'none';
  let ruleIds = [];
  let usedReferrer = '';

  // 1) DNR Referer unlock FIRST — must be active before any navigation.
  if (destIsPanel && referrer) {
    const installed = await installUnlockReferrerRules(
      destinationUrl,
      referrer,
      referrerCandidates,
    );
    ruleIds = installed.ruleIds || [];
    unlockMode = installed.mode;
    usedReferrer = installed.referrer || referrer;
  }

  // 2) Wipe personal session (cookies + localStorage/IDB) so customer ChatGPT
  //    cannot keep "my own account" after we apply admin cookies.
  if (!destIsPanel && list.length > 0) {
    await clearSiteStorage(destinationUrl);
    await clearSiteCookies(destinationUrl, list);
  }

  // 3) Apply all cookies and wait for each set to finish.
  for (const cookie of list) {
    if (!cookie || !cookie.name) continue;
    const path = cookie.path || '/';
    const jsonDomain = cookie.domain ? String(cookie.domain) : '';
    const jsonHost = normalizeDomain(jsonDomain);
    const cookieIsToolAccess =
      isToolAccessHost(jsonHost) ||
      (cookie.url && isToolAccessHost(destinationHost(String(cookie.url))));

    let applied = false;

    // Prefer cookie.url / cookie.domain exactly as exported
    if (cookie.url) {
      const urlHost = destinationHost(String(cookie.url));
      if (!destIsPanel || isToolAccessHost(urlHost) || !urlHost) {
        applied = await setOne(buildSetDetails(cookie, String(cookie.url), jsonDomain || undefined));
        if (applied) setCount += 1;
      }
    } else if (jsonHost) {
      if (!destIsPanel || isToolAccessHost(jsonHost)) {
        const url = cookieUrlFor(jsonHost, path, cookie.secure !== false && destIsHttps);
        applied = await setOne(buildSetDetails(cookie, url, jsonDomain));
        if (applied) setCount += 1;
      }
    }

    // toolaccess destination: dual-write onto exact host + parent
    if (destIsPanel && destHost && (cookieIsToolAccess || !jsonHost)) {
      setCount += await applyOnToolAccessPanel(cookie, destHost, path, destIsHttps);
      applied = true;
    }

    // Non-panel destinations: only when JSON has no domain/url, set on dest
    if (!applied && !destIsPanel && destHost) {
      const destUrl = cookieUrlFor(destHost, path, destIsHttps);
      if (await setOne(buildSetDetails(cookie, destUrl, undefined))) setCount += 1;

      const parts = destHost.split('.');
      if (parts.length >= 2) {
        const registrable = parts.slice(-2).join('.');
        const parent = `.${registrable}`;
        const parentUrl = cookieUrlFor(registrable, path, destIsHttps);
        if (await setOne(buildSetDetails(cookie, parentUrl, parent))) setCount += 1;
      }
    }
  }

  // 4) Brief settle so cookie jar is visible before portal/extension navigation.
  if (list.length > 0 || ruleIds.length || destIsPanel) {
    await sleep(SETTLE_MS);
  }

  // Admin cookies were provided but none could be written — fail closed (don't open logged-out).
  if (list.length > 0 && setCount === 0 && !destIsPanel) {
    return {
      ok: false,
      error:
        'Could not write session cookies for this tool. Reload ZynexTools v1.4.0+, confirm admin saved valid Copy Cookies JSON, then try again.',
      count: list.length,
      setCount: 0,
      unlockMode,
      unlockRules: ruleIds.length,
      unlockReferrer: usedReferrer || referrer || '',
    };
  }

  // Never open a bare toolaccess URL without Referer rules — that is the 403 path.
  if (openTab && destIsPanel && ruleIds.length === 0) {
    return {
      ok: false,
      error:
        'Could not install panel Referer unlock rules. Update or reload the ZynexTools extension (v1.4.0+), then try again.',
      count: list.length,
      setCount,
      unlockMode,
      unlockRules: 0,
      unlockReferrer: usedReferrer || referrer || '',
    };
  }

  let tab = null;
  if (openTab && destinationUrl) {
    tab = await chrome.tabs.create({ url: destinationUrl });

    if (tab?.id != null && ruleIds.length) {
      const tabId = tab.id;
      const timer = setTimeout(() => clearTabUnlock(tabId), UNLOCK_RULE_TTL_MS);
      activeUnlockByTab.set(tabId, { ruleIds, timer });
    } else if (ruleIds.length && !tab) {
      setTimeout(() => removeUnlockRules(ruleIds), UNLOCK_RULE_TTL_MS);
    }

    if (
      tab?.id != null &&
      privacy?.hideSharedHistory &&
      /chatgpt\.com|openai\.com/i.test(String(destinationUrl || ''))
    ) {
      const tabId = tab.id;
      const onReady = (id, info) => {
        if (id !== tabId || info.status !== 'complete') return;
        chrome.tabs.onUpdated.removeListener(onReady);
        void injectChatGptPrivacy(tabId, privacy.isolationKey, privacy.brandName);
      };
      chrome.tabs.onUpdated.addListener(onReady);
      setTimeout(() => chrome.tabs.onUpdated.removeListener(onReady), 60000);
    }
  } else if (ruleIds.length) {
    setTimeout(() => removeUnlockRules(ruleIds), UNLOCK_RULE_TTL_MS);
  }

  return {
    ok: true,
    count: list.length,
    setCount,
    unlockMode,
    unlockRules: ruleIds.length,
    unlockReferrer: usedReferrer || referrer || '',
  };
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'complete' && activeUnlockByTab.has(tabId)) {
    // Keep rules briefly after first complete so XHR/subresources still get Referer.
    const entry = activeUnlockByTab.get(tabId);
    if (entry?.timer) clearTimeout(entry.timer);
    const timer = setTimeout(() => clearTabUnlock(tabId), 8000);
    activeUnlockByTab.set(tabId, { ...entry, timer });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  clearTabUnlock(tabId);
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message) return;
  if (message.type === 'PING') {
    sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
    return;
  }
  if (message.type !== 'APPLY_COOKIES') return;
  const unlockReferrer =
    message.unlockReferrer || message.panelReferrer || message.referrer || '';
  const referrerCandidates = Array.isArray(message.referrerCandidates)
    ? message.referrerCandidates
    : [];
  applyCookies(
    message.cookies,
    message.url,
    Boolean(message.openTab),
    unlockReferrer,
    referrerCandidates,
    {
      hideSharedHistory: Boolean(message.hideSharedHistory),
      isolationKey: message.isolationKey || '',
      brandName: message.brandName || 'ZynexTools',
    },
  )
    .then(sendResponse)
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});
