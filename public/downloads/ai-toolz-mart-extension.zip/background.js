/** Temporary DNR rule ids for panel Referer unlock (session rules). */
const UNLOCK_RULE_TTL_MS = 45000;
let nextRuleId = 900001;
const activeUnlockByTab = new Map(); // tabId -> { ruleIds, timer }

function destinationHost(destinationUrl) {
  try {
    return new URL(destinationUrl).hostname.toLowerCase();
  } catch {
    return '';
  }
}

function normalizeDomain(domain) {
  return String(domain || '').trim().toLowerCase().replace(/^\./, '');
}

function isToolAccessHost(hostname) {
  const host = String(hostname || '').toLowerCase();
  return host === 'toolaccess.click' || host.endsWith('.toolaccess.click');
}

function cookieUrlFor(host, path, secure) {
  const cleanHost = String(host || '').replace(/^\./, '');
  const cleanPath = path && String(path).startsWith('/') ? String(path) : `/${path || ''}`;
  return `${secure ? 'https' : 'http'}://${cleanHost}${cleanPath || '/'}`;
}

function sameSite(value) {
  const raw = String(value || '').toLowerCase();
  if (raw === 'lax') return 'lax';
  if (raw === 'strict') return 'strict';
  if (raw === 'no_restriction' || raw === 'none') return 'no_restriction';
  return undefined;
}

function expirationDate(cookie) {
  if (cookie.expirationDate != null && cookie.expirationDate !== '') {
    const n = Number(cookie.expirationDate);
    return Number.isFinite(n) ? n : undefined;
  }
  if (cookie.expires != null && cookie.expires !== '' && cookie.expires !== -1) {
    const n = Number(cookie.expires);
    if (!Number.isFinite(n)) return undefined;
    return n > 1e12 ? n / 1000 : n;
  }
  return undefined;
}

function buildSetDetails(cookie, url, domain) {
  const secureDest = /^https:/i.test(url);
  let secure = cookie.secure;
  if (secure == null) secure = secureDest;
  else secure = Boolean(secure);

  const site = sameSite(cookie.sameSite);
  if (site === 'no_restriction') secure = true;

  const details = {
    url,
    name: String(cookie.name),
    value: String(cookie.value ?? ''),
    path: cookie.path || '/',
    secure: Boolean(secure),
    httpOnly: Boolean(cookie.httpOnly),
  };
  if (domain) details.domain = domain;
  const exp = expirationDate(cookie);
  if (exp != null) details.expirationDate = exp;
  if (site) details.sameSite = site;
  return details;
}

async function setOne(details) {
  try {
    await chrome.cookies.set(details);
    return true;
  } catch (error) {
    console.warn('Could not set cookie', details.name, details.url, details.domain, error);
    return false;
  }
}

/**
 * For *.toolaccess.click destinations: write matching cookies as
 * host-only on the exact subdomain AND on parent .toolaccess.click.
 * Never remaps foreign domains (e.g. chatgpt.com) onto the panel.
 */
async function applyOnToolAccessPanel(cookie, destHost, path, destIsHttps) {
  let setCount = 0;
  const destUrl = cookieUrlFor(destHost, path, destIsHttps);
  if (await setOne(buildSetDetails(cookie, destUrl, undefined))) setCount += 1;

  const parent = '.toolaccess.click';
  const parentUrl = cookieUrlFor('toolaccess.click', path, destIsHttps);
  if (await setOne(buildSetDetails(cookie, parentUrl, parent))) setCount += 1;

  if (destHost !== 'toolaccess.click') {
    const apexUrl = cookieUrlFor('toolaccess.click', path, destIsHttps);
    if (await setOne(buildSetDetails(cookie, apexUrl, undefined))) setCount += 1;
  }
  return setCount;
}

async function removeUnlockRules(ruleIds) {
  const ids = (ruleIds || []).filter((id) => Number.isFinite(id));
  if (!ids.length || !chrome.declarativeNetRequest?.updateSessionRules) return;
  try {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: ids, addRules: [] });
  } catch (error) {
    console.warn('Could not remove unlock DNR rules', error);
  }
}

function clearTabUnlock(tabId) {
  const entry = activeUnlockByTab.get(tabId);
  if (!entry) return;
  if (entry.timer) clearTimeout(entry.timer);
  activeUnlockByTab.delete(tabId);
  void removeUnlockRules(entry.ruleIds);
}

/**
 * Install temporary session DNR rules to set Referer (and Origin when allowed)
 * on requests to the toolaccess host. Returns rule ids or [] if unavailable.
 */
async function installUnlockReferrerRules(destinationUrl, referrerUrl) {
  const destHost = destinationHost(destinationUrl);
  const referrer = String(referrerUrl || '').trim();
  if (!referrer || !isToolAccessHost(destHost)) return { ruleIds: [], mode: 'none' };
  if (!chrome.declarativeNetRequest?.updateSessionRules) {
    return { ruleIds: [], mode: 'unsupported' };
  }

  let origin = '';
  try {
    origin = new URL(referrer).origin;
  } catch {
    return { ruleIds: [], mode: 'invalid' };
  }

  const ruleId = nextRuleId++;
  if (nextRuleId > 990000) nextRuleId = 900001;

  const requestHeaders = [
    { header: 'Referer', operation: 'set', value: referrer },
  ];
  // Origin is often restricted; try with it first, fall back to Referer-only.
  const withOrigin = [
    ...requestHeaders,
    { header: 'Origin', operation: 'set', value: origin },
  ];

  const condition = {
    urlFilter: `||${destHost}^`,
    resourceTypes: [
      'main_frame',
      'sub_frame',
      'xmlhttprequest',
      'websocket',
      'other',
      'script',
      'stylesheet',
      'image',
      'font',
      'ping',
    ],
  };

  const tryAdd = async (headers) => {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [ruleId],
      addRules: [
        {
          id: ruleId,
          priority: 100,
          action: { type: 'modifyHeaders', requestHeaders: headers },
          condition,
        },
      ],
    });
  };

  try {
    await tryAdd(withOrigin);
    return { ruleIds: [ruleId], mode: 'referer+origin' };
  } catch (err1) {
    console.warn('DNR Origin rewrite rejected, trying Referer only', err1);
    try {
      await tryAdd(requestHeaders);
      return { ruleIds: [ruleId], mode: 'referer' };
    } catch (err2) {
      console.warn('DNR Referer rewrite unavailable', err2);
      return { ruleIds: [], mode: 'failed' };
    }
  }
}

/**
 * Fallback when DNR cannot set Referer: open an extension page that navigates
 * with location.replace after a document.referrer context is limited — Chrome
 * still may not send a custom Referer from extension pages. Documented limit.
 */
async function openWithReferrerFallback(destinationUrl, referrerUrl) {
  const dest = encodeURIComponent(destinationUrl);
  const ref = encodeURIComponent(String(referrerUrl || ''));
  const url = chrome.runtime.getURL(`unlock.html?dest=${dest}&ref=${ref}`);
  return chrome.tabs.create({ url });
}

/**
 * Apply Copy-Cookies JSON via chrome.cookies.set using each cookie's own
 * domain/url from the export (e.g. chatgpt.com cookies stay on chatgpt.com).
 *
 * For toolaccess.click destinations, also dual-write toolaccess-scoped
 * cookies onto the exact host (host-only) + parent domain before navigate.
 * When unlockReferrer is set, install temporary DNR Referer rules first.
 */
async function applyCookies(cookies, destinationUrl, openTab, unlockReferrer) {
  const list = Array.isArray(cookies) ? cookies : [];
  const destHost = destinationHost(destinationUrl);
  const destIsHttps = !/^http:\/\//i.test(destinationUrl || '');
  const destIsPanel = isToolAccessHost(destHost);
  const referrer = destIsPanel ? String(unlockReferrer || '').trim() : '';
  let setCount = 0;
  let unlockMode = 'none';
  let ruleIds = [];

  if (referrer) {
    const installed = await installUnlockReferrerRules(destinationUrl, referrer);
    ruleIds = installed.ruleIds || [];
    unlockMode = installed.mode;
  }

  for (const cookie of list) {
    if (!cookie || !cookie.name) continue;
    const path = cookie.path || '/';
    const jsonDomain = cookie.domain ? String(cookie.domain) : '';
    const jsonHost = normalizeDomain(jsonDomain);
    const cookieIsToolAccess =
      isToolAccessHost(jsonHost) ||
      (cookie.url && isToolAccessHost(destinationHost(String(cookie.url))));

    let applied = false;

    // 1) Prefer cookie.url / cookie.domain exactly as exported
    if (cookie.url) {
      const urlHost = destinationHost(String(cookie.url));
      if (!destIsPanel || isToolAccessHost(urlHost) || !urlHost) {
        applied = await setOne(buildSetDetails(cookie, String(cookie.url), jsonDomain || undefined));
        if (applied) setCount += 1;
      }
    } else if (jsonHost) {
      if (!destIsPanel || isToolAccessHost(jsonHost)) {
        const url = cookieUrlFor(jsonHost, path, cookie.secure !== false && destIsHttps);
        applied = await setOne(buildSetDetails(cookie, url, jsonDomain));
        if (applied) setCount += 1;
      }
    }

    // 2) toolaccess destination: dual-write onto exact host + parent
    if (destIsPanel && destHost && (cookieIsToolAccess || !jsonHost)) {
      setCount += await applyOnToolAccessPanel(cookie, destHost, path, destIsHttps);
      applied = true;
    }

    // 3) Non-panel destinations: only when JSON has no domain/url, set on dest
    if (!applied && !destIsPanel && destHost) {
      const destUrl = cookieUrlFor(destHost, path, destIsHttps);
      if (await setOne(buildSetDetails(cookie, destUrl, undefined))) setCount += 1;

      const parts = destHost.split('.');
      if (parts.length >= 2) {
        const registrable = parts.slice(-2).join('.');
        const parent = `.${registrable}`;
        const parentUrl = cookieUrlFor(registrable, path, destIsHttps);
        if (await setOne(buildSetDetails(cookie, parentUrl, parent))) setCount += 1;
      }
    }
  }

  let tab = null;
  if (openTab && destinationUrl) {
    if (referrer && unlockMode === 'failed') {
      tab = await openWithReferrerFallback(destinationUrl, referrer);
    } else {
      tab = await chrome.tabs.create({ url: destinationUrl });
    }

    if (tab?.id != null && ruleIds.length) {
      const tabId = tab.id;
      const timer = setTimeout(() => clearTabUnlock(tabId), UNLOCK_RULE_TTL_MS);
      activeUnlockByTab.set(tabId, { ruleIds, timer });
    } else if (ruleIds.length && !tab) {
      setTimeout(() => removeUnlockRules(ruleIds), UNLOCK_RULE_TTL_MS);
    }
  } else if (ruleIds.length) {
    setTimeout(() => removeUnlockRules(ruleIds), UNLOCK_RULE_TTL_MS);
  }

  return {
    ok: true,
    count: list.length,
    setCount,
    unlockMode,
    unlockRules: ruleIds.length,
  };
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'complete' && activeUnlockByTab.has(tabId)) {
    // Keep rules briefly after first complete so XHR/subresources still get Referer.
    const entry = activeUnlockByTab.get(tabId);
    if (entry?.timer) clearTimeout(entry.timer);
    const timer = setTimeout(() => clearTabUnlock(tabId), 8000);
    activeUnlockByTab.set(tabId, { ...entry, timer });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  clearTabUnlock(tabId);
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message) return;
  if (message.type === 'PING') {
    sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
    return;
  }
  if (message.type !== 'APPLY_COOKIES') return;
  const unlockReferrer =
    message.unlockReferrer || message.panelReferrer || message.referrer || '';
  applyCookies(message.cookies, message.url, Boolean(message.openTab), unlockReferrer)
    .then(sendResponse)
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});
